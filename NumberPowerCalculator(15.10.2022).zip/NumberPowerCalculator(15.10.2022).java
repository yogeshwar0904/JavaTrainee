import java.util.InputMismatchException;
import java.util.Scanner;


/**
 * power the given number.
 */
public class NumberPowerCalculator {
    public static void main(String[] args) {
        powerTheNumber();   
    }
    public static int () {
        int baseNumber;
        int numberPower;
        int number = 1;
        boolean isContinue = false;
        do {
            try {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Enter the base Number");
                baseNumber = scanner.nextInt();
                System.out.println("Enter the number to power the base number");
                numberPower = scanner.nextInt(); 
        
                while (numberPower != 0) {
                    number = number * baseNumber;
                    numberPower--;
                }
                StringBuilder userControll = new StringBuilder();
                userControll.append("The value of ").append(baseNumber)
                            .append(" is ").append(number);
                System.out.println(userControll);
            } catch(InputMismatchException inputMismatch) {
                System.out.println("Entered invalid input");
                isContinue = true;
            }
            return number;
        } while (isContinue);
         System.out.println("hello");      
    }
}